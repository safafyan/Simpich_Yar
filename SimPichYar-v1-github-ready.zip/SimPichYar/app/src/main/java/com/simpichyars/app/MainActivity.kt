package com.simpichyars.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import kotlin.math.PI
import kotlin.math.sqrt

class MainActivity : Activity() {
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }

    private fun base(title:String): LinearLayout {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(22),dp(18),dp(18)); setBackgroundColor(Color.WHITE); layoutDirection=LinearLayout.RTL }
        val t=TextView(this).apply { text=title; textSize=27f; setTextColor(Color.rgb(25,45,65)); gravity=Gravity.CENTER; setPadding(0,0,0,dp(18)) }
        root.addView(t, LinearLayout.LayoutParams(-1,dp(65))); return root
    }
    private fun btn(text:String, action:()->Unit): Button = Button(this).apply { this.text=text; textSize=17f; setOnClickListener{action()}; isAllCaps=false }

    private fun showHome(){
        val r=base("سیم‌پیچ‌یار 🔧")
        val sub=TextView(this).apply { text="دستیار محاسبات و ثبت اطلاعات سیم‌پیچی"; textSize=16f; gravity=Gravity.CENTER; setPadding(0,0,0,dp(20)) }; r.addView(sub)
        r.addView(btn("📐 تبدیل قطر سیم و تعداد دور"){showConverter()}); r.addView(btn("🧲 محاسبه سطح مقطع سیم"){showArea()}); r.addView(btn("📋 ثبت مشخصات موتور"){showMotor()}); r.addView(btn("🗺️ نقشه سیم‌پیچی"){Toast.makeText(this,"این بخش در نسخه بعدی تکمیل می‌شود.",Toast.LENGTH_SHORT).show()})
        setContentView(r)
    }
    private fun field(hint:String): EditText = EditText(this).apply { this.hint=hint; inputType=2; textSize=17f; setPadding(dp(12),dp(8),dp(12),dp(8)) }
    private fun showConverter(){
        val r=base("تبدیل قطر سیم و تعداد دور"); val old=field("قطر سیم قبلی (میلی‌متر)"); val turns=field("تعداد دور قبلی"); val nw=field("قطر سیم جدید (میلی‌متر)"); r.addView(old);r.addView(turns);r.addView(nw)
        val out=TextView(this).apply{textSize=20f;setPadding(0,dp(20),0,dp(10))}; r.addView(btn("محاسبه"){try{val d=old.text.toString().toDouble();val n=turns.text.toString().toDouble();val x=n*d*d/(nw.text.toString().toDouble().let{it*it});out.text="تعداد دور تقریبی جدید: %.1f دور".format(x)}catch(_:Exception){out.text="لطفاً هر سه مقدار را درست وارد کنید."}});r.addView(out);r.addView(btn("← برگشت"){showHome()});setContentView(r)
    }
    private fun showArea(){
        val r=base("سطح مقطع سیم"); val d=field("قطر سیم (میلی‌متر)"); r.addView(d); val out=TextView(this).apply{textSize=20f;setPadding(0,dp(20),0,dp(10))};r.addView(btn("محاسبه"){try{val x=d.text.toString().toDouble();out.text="سطح مقطع: %.4f mm²".format(PI*x*x/4)}catch(_:Exception){out.text="قطر سیم را وارد کنید."}});r.addView(out);r.addView(btn("← برگشت"){showHome()});setContentView(r)
    }
    private fun showMotor(){
        val r=base("ثبت مشخصات موتور"); listOf("نام/مدل موتور","توان (kW)","دور (rpm)","ولتاژ (V)","جریان (A)","تعداد شیار").forEach{r.addView(field(it))}; r.addView(btn("ذخیره موقت"){Toast.makeText(this,"در نسخه بعدی ذخیره دائمی اضافه می‌شود.",Toast.LENGTH_SHORT).show()});r.addView(btn("← برگشت"){showHome()});setContentView(r)
    }
}
